import React, { useState } from 'react';
import axios from 'axios';
import './App.css'; // Import CSS file for styling
import { Link } from 'react-router-dom';
const DietRecord = () => {
  const [diet, setDiet] = useState('');
  const [workout, setWorkout] = useState('');
  const [sleepingHour, setSleepingHour] = useState('');
  const [water, setWater] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('http://localhost:8000/diet/fill', {
        diet,
        workout,
        sleepingHour,
        water
      });
      console.log('Record created:', response.data);
      // Reset form fields
      setDiet('');
      setWorkout('');
      setSleepingHour('');
      setWater('');
    } catch (error) {
      console.error('Error creating record:', error);
    }
  };

  return (
  <div>

   
   
    <section class="p-6 dark:bg-gray-800 dark:text-gray-100">
	<div class="container grid gap-6 mx-auto text-center lg:grid-cols-2 xl:grid-cols-5">
		<div class="w-full px-6 py-16 rounded-md sm:px-12 md:px-16 xl:col-span-2 dark:bg-gray-900">
			<span class="block mb-2 dark:text-violet-400">Mr Health</span>
			<h1 class="text-5xl font-extrabold dark:text-gray-50">Build your health</h1>
			<p class="my-8">
				<span class="font-medium dark:text-gray-50">Modular and versatile.</span>Fugit vero facilis dolor sit neque cupiditate minus esse accusamus cumque at.
			</p>
    <form onSubmit={handleSubmit} className="self-stretch space-y-3">
			
				<div>
					<label for="name" class="text-sm sr-only">Diet</label>
					<input  type="text" placeholder="Diet" value={diet} onChange={(e) => setDiet(e.target.value)} class="w-full rounded-md focus:ring focus:ri dark:border-gray-700"/>
				</div>
				<div>
					<label for="lastname" class="text-sm sr-only">WorkOut</label>
					<input  type="text" placeholder="Workout" value={workout} onChange={(e) => setWorkout(e.target.value)}  class="w-full rounded-md focus:ring focus:ri dark:border-gray-700"/>
				</div>
        <div>
					<label for="lastname" class="text-sm sr-only">Sleepinghour</label>
					<input  type="text" placeholder="Sleeping Hour" value={sleepingHour} onChange={(e) => setSleepingHour(e.target.value)}  class="w-full rounded-md focus:ring focus:ri dark:border-gray-700"/>
				</div>
        <div>
					<label for="water" class="text-sm sr-only">Water</label>
					<input  type="number" placeholder="Water" value={water} onChange={(e) => setWater(e.target.value)}  class="w-full rounded-md focus:ring focus:ri dark:border-gray-700"/>
				</div>
         <button type="submit" 
				 class="w-full py-2 font-semibold rounded dark:bg-violet-400 dark:text-gray-900">submit</button>
			
      </form>
		</div>
		<img src="https://source.unsplash.com/random/480x360" alt="" class="object-cover w-full rounded-md xl:col-span-3 dark:bg-gray-500"/>
	</div>
</section>

<Link to="/wel">
<center>
<button class="mt-6 py-2 px-4 bg-yellow-400 text-gray-800 font-bold rounded-lg shadow-md hover:shadow-lg transition duration-300 ">Back In</button>
</center>
</Link> 




</div>


  );
};

export default DietRecord;
