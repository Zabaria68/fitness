import React, { useState } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';

const RegisterForm = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    role: '',
    image: null
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleFileChange = (e) => {
    setFormData({ ...formData, image: e.target.files[0] });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const formDataToSend = new FormData();
      formDataToSend.append('name', formData.name);
      formDataToSend.append('email', formData.email);
      formDataToSend.append('password', formData.password);
      formDataToSend.append('role', formData.role);
      formDataToSend.append('image', formData.image);

      const response = await axios.post('http://localhost:8000/auth/user', formDataToSend);
      const { user, token } = response.data;

      localStorage.setItem('token', token);

      console.log('User registered:', user);
    } catch (error) {
      console.error('Registration failed:', error.response.data.message);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-r from-red-600 to-yellow-400 flex items-center justify-center">
      <div className="w-full max-w-md bg-white rounded-lg shadow-lg overflow-hidden">
        <div className="px-6 py-4">
          <h2 className="text-center font-semibold text-2xl text-gray-800">Register</h2>
          <p className="text-center text-gray-600 mt-1">Please fill in the form to register</p>
          <form onSubmit={handleSubmit} className="mt-4">
            <div>
              <input type="text" name="name" value={formData.name} onChange={handleChange} placeholder="Name" className="block w-full px-4 py-3 mt-1 text-gray-800 appearance-none border rounded-md focus:outline-none focus:border-red-600" />
            </div>
            <div className="mt-4">
              <input type="email" name="email" value={formData.email} onChange={handleChange} placeholder="Email Address" className="block w-full px-4 py-3 mt-1 text-gray-800 appearance-none border rounded-md focus:outline-none focus:border-red-600" />
            </div>
            <div className="mt-4">
              <input type="password" name="password" value={formData.password} onChange={handleChange} placeholder="Password" className="block w-full px-4 py-3 mt-1 text-gray-800 appearance-none border rounded-md focus:outline-none focus:border-red-600" />
            </div>
            <div className="mt-4">
              <input type="text" name="role" value={formData.role} onChange={handleChange} placeholder="Role" className="block w-full px-4 py-3 mt-1 text-gray-800 appearance-none border rounded-md focus:outline-none focus:border-red-600" />
            </div>
            <div className="mt-4">
              <input type="file" id="image" name="image" onChange={handleFileChange} accept="image/*" className="hidden" />
              <label htmlFor="image" className="block w-full px-4 py-3 text-center text-white bg-blue-600 rounded-md cursor-pointer hover:bg-blue-700">
                Choose Image
              </label>
            </div>
            <div className="mt-4">
              <button type="submit" className="w-full px-4 py-3 text-white bg-red-600 rounded-md hover:bg-red-700 focus:outline-none focus:bg-red-700">Register</button>
            </div>
            <div className="mt-4 text-center">
              <span className="text-gray-600">Already have an account?</span>
              <Link to="/log" className="ml-1 text-blue-600 hover:underline">Log in</Link>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default RegisterForm;