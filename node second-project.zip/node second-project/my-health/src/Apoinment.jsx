import React, { useState } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';

const Apoinment= () => {
  const [formData, setFormData] = useState({
    heartbeat: '',
    image: null,
    title: '',
    age: '',
    gender: '',
    countryCode: '',
    height: '',
    weight: '',
    diet: ''
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleFileChange = (e) => {
    setFormData({ ...formData, image: e.target.files[0] });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const formDataToSend = new FormData();
      formDataToSend.append('heartbeat', formData.heartbeat);
      formDataToSend.append('image', formData.image);
      formDataToSend.append('title', formData.title);
      formDataToSend.append('age', formData.age);
      formDataToSend.append('gender', formData.gender);
      formDataToSend.append('countryCode', formData.countryCode);
      formDataToSend.append('height', formData.height);
      formDataToSend.append('weight', formData.weight);
      formDataToSend.append('diet', formData.diet);

      const response = await axios.post('http://localhost:8000/crud/record', formDataToSend);
   console.log(response.data)
    } catch (error) {
      console.error('Registration failed:', error.response.data.message);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-r from-red-600 to-yellow-400 flex items-center justify-center">
      <div className="w-full max-w-md bg-white rounded-lg shadow-lg overflow-hidden">
        <div className="px-6 py-4">
          <h2 className="text-center font-semibold text-2xl text-gray-800">Booking</h2>
          <p className="text-center text-gray-600 mt-1">How can i help You Sir? <br />

           Please fill this Form </p>
          <form onSubmit={handleSubmit} className="mt-4">
            <div>
              <input type="text" name="heartbeat" value={formData.heartbeat} onChange={handleChange} placeholder="Name" className="block w-full px-4 py-3 mt-1 text-gray-800 appearance-none border rounded-md focus:outline-none focus:border-red-600" />
            </div>
    
            <div className="mt-4">
              <input type="text" name="title" value={formData.title} onChange={handleChange} placeholder="Title" className="block w-full px-4 py-3 mt-1 text-gray-800 appearance-none border rounded-md focus:outline-none focus:border-red-600" />
            </div>
            <div className="mt-4">
              <input type="text" name="age" value={formData.age} onChange={handleChange} placeholder="Age" className="block w-full px-4 py-3 mt-1 text-gray-800 appearance-none border rounded-md focus:outline-none focus:border-red-600" />
            </div>
            <div className="mt-4">
              <input type="text" name="gender" value={formData.gender} onChange={handleChange} placeholder="Gender" className="block w-full px-4 py-3 mt-1 text-gray-800 appearance-none border rounded-md focus:outline-none focus:border-red-600" />
            </div>
            <div className="mt-4">
              <input type="text" name="countryCode" value={formData.countryCode} onChange={handleChange} placeholder="Country Code" className="block w-full px-4 py-3 mt-1 text-gray-800 appearance-none border rounded-md focus:outline-none focus:border-red-600" />
            </div>
            <div className="mt-4">
              <input type="text" name="height" value={formData.height} onChange={handleChange} placeholder="Height" className="block w-full px-4 py-3 mt-1 text-gray-800 appearance-none border rounded-md focus:outline-none focus:border-red-600" />
            </div>
            <div className="mt-4">
              <input type="text" name="weight" value={formData.weight} onChange={handleChange} placeholder="Weight" className="block w-full px-4 py-3 mt-1 text-gray-800 appearance-none border rounded-md focus:outline-none focus:border-red-600" />
            </div>
            <div className="mt-4">
              <input type="text" name="diet" value={formData.diet} onChange={handleChange} placeholder="Diet" className="block w-full px-4 py-3 mt-1 text-gray-800 appearance-none border rounded-md focus:outline-none focus:border-red-600" />
            </div>
            <div className="mt-4">
              <input type="file" id="image" name="image" onChange={handleFileChange} accept="image/*" className="hidden" />
              <label htmlFor="image" className="block w-full px-4 py-3 text-center text-white bg-blue-600 rounded-md cursor-pointer hover:bg-blue-700">
                Choose Image
              </label>
            </div>
            <div className="mt-4">
              <button type="submit" className="w-full px-4 py-3 text-white bg-red-600 rounded-md hover:bg-red-700 focus:outline-none focus:bg-red-700">Done</button>
            </div>
            <div className="mt-4 text-center">
              <span className="text-gray-600">Shukriya !</span>
              <Link to="/wel" className="ml-1 text-blue-600 hover:underline">Welcome</Link>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Apoinment;