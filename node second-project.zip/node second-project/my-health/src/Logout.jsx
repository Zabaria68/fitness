import React from 'react'
import { Link } from 'react-router-dom'
function Logout() {
const Kill=()=>{

  localStorage.removeItem("token")
 
}
  return (
    <div>
      <Link to="/"><button onClick={Kill}>Logout</button></Link>
    </div>
  )
}

export default Logout