import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import LoginForm from './LoginForm';
import Welcome from './Welcome'
import RegisterForm from './RegisterForm';
import Profile from './Profile';
import CrudProfile from './CrudProfile';
import CrudComponent from './CrudComponent';
import Contact from './Contact';
import DietRecord from './DietRecord';
import Apoinment from './Apoinment';
import Home from './Home';
import About from './About';
import FigureCalculator from './FigureCalculator';
// import LogoutButton from './Logout';

const App = () => {
  return (
    <div>
      <Router>
      
        <Routes>
          <Route path="/wel" element={<Welcome />} />
          <Route path="/home" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/log" element={<LoginForm />} />
          <Route path="/" element={<RegisterForm />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/cn" element={<Contact />} />
          <Route path="/crudprofile" element={<CrudProfile />} />
          <Route path="/h" element={<CrudComponent />} />
          <Route path="/f" element={<DietRecord />} />
          <Route path="/ap" element={<Apoinment />} />
          <Route path="/cal" element={<FigureCalculator />} />
          {/* <Route path="/logout" element={<LogoutButton />} /> */}
         
        </Routes>
      </Router>
    </div>
  );
};

export default App;