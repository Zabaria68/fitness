import React, { useState, useEffect } from 'react';
import axios from 'axios';

const CrudProfile = () => {
  const [records, setRecords] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get('http://localhost:8000/crud/allRecords');
        setRecords(response.data);
        setLoading(false);
      } catch (error) {
        setError(error.response.data.message);
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  return (
    <div>
      <h2>Records List</h2>
      {loading ? (
        <p>Loading...</p>
      ) : error ? (
        <p>Error: {error}</p>
      ) : (
        <ul>
          {records.map(record => (
            <li key={record._id} style={{ marginBottom: '20px', border: '1px solid #ccc', padding: '10px', borderRadius: '5px' }}>
              <h3>{record.title}</h3>
              <p><strong>Name:</strong> {record.name}</p>
              <p><strong>Age:</strong> {record.age}</p>
              <p><strong>Gender:</strong> {record.gender}</p>
              <p><strong>Diet:</strong> {record.diet}</p>
              <p><strong>Weight:</strong> {record.weight}</p>
              <p><strong>Height:</strong> {record.height}</p>
              <p><strong>Country Code:</strong> {record.countryCode}</p>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default CrudProfile;
