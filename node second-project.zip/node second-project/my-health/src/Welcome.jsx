import React from 'react'
import { Link } from 'react-router-dom'

function Welcome() {
  return (
    <div>

    
<div class="nn">
<header class="header-background bg-opacity-75 text-black shadow-lg hidden md:block">
  <div class="container mx-auto flex items-center h-24">
    <Link to="/" class="flex items-center justify-center">
      <img class="h-16" src="https://i.ibb.co/6Yxs70d/2021-10-26-23h27-03.png" alt="" />
      <span class="ml-4 uppercase font-black">Health<br/>CARE</span>
    </Link>
    <nav class="contents font-semibold text-base lg:text-lg">
      <ul class="mx-auto flex items-center">
        <li class="p-5 xl:p-8 active">
         <Link to ="/home ">Home</Link>
        </li>
        <li class="p-5 xl:p-8">
        <Link to="/about">About</Link>
        </li>
        
        <li class="p-5 xl:p-8">
         <Link to="/h">Services</Link>
        </li>
        <li class="p-5 xl:p-8">
         <Link to="/cal">BMI CAL</Link>
        </li>
        <li class="p-5 xl:p-8">
          <Link to="/">Login</Link>
        </li>
      </ul>
    </nav>
    <Link to="/con">
    <button class="border border-white rounded-full font-bold px-8 py-2">Contact me</button></Link>
    <Link to="/crudprofile">
    <button class="border border-white rounded-full font-bold px-8 py-2">Database</button></Link>

  </div>
</header>


<div class="min-h-screen bg-gray-100 flex justify-center items-center">
  <div class="container flex justify-center">
    <div class="max-w-sm py-32">
      <div class="bg-white relative shadow-lg hover:shadow-xl transition duration-500 rounded-lg">
        <img class="rounded-t-lg" src="https://images.unsplash.com/photo-1583511655857-d19b40a7a54e?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1049&q=80" alt="" />
        <div class="py-6 px-8 rounded-lg bg-white">
          <h1 class="text-gray-700 font-bold text-2xl mb-3 hover:text-gray-900 hover:cursor-pointer">I'm here for you.</h1>
          <p class="text-gray-700 tracking-wide">Lorem ipsum dolor sit amet consectetur,  Lorem ipsum dolor sit, amet consectetur adipisicing elit. Labore exercitationem,<br /> dolor necessitatibus in cum molestias distinctio illum odio aliquid excepturi nulla error optio culpa <br />adipisci itaque. Fugit vitae autem dolorum!adipisicing elit. Eum, labore. Ea debitis beatae sequi deleniti.</p>
         <Link to="/ap"><button class="mt-6 py-2 px-4 bg-yellow-400 text-gray-800 font-bold rounded-lg shadow-md hover:shadow-lg transition duration-300">Book Now</button></Link>
        </div>
        <div class="absolute top-2 right-2 py-2 px-4 bg-white rounded-lg">
          <span class="text-md">$150</span>
        </div>
      </div>
    </div>
  </div>
</div>


</div>
    </div>
  )
}

export default Welcome;