import React, { useState } from 'react';
import axios from 'axios';

const WaterRecordComponent = () => {
  const [record, setRecord] = useState(null);
  const [error, setError] = useState('');
  const [water, setWater] = useState('');

  const handleSearch = async () => {
    try {
      const response = await axios.get(` http://localhost:8000/diet/height/${water}`);
      setRecord(response.data);
      setError('');
    } catch (error) {
      if (error) {
        setError('No record found');
      } else {
        setError('An error occurred');
      }
      setRecord(null);
    }
  };

  return (
    <div style={{ fontFamily: 'Arial, sans-serif', maxWidth: '400px', margin: 'auto' }}>
      <h2 style={{ textAlign: 'center', marginBottom: '20px' }}>Search Records by Water Intake</h2>
      <div style={{ display: 'flex', alignItems: 'center', marginBottom: '20px' }}>
        <input 
          type="number" 
          placeholder="Enter water intake" 
          value={water} 
          onChange={(e) => setWater(e.target.value)} 
          style={{ flex: '1', padding: '8px', marginRight: '10px', borderRadius: '5px', border: '1px solid #ccc' }}
        />
        <button onClick={handleSearch} style={{ padding: '8px 20px', borderRadius: '5px', backgroundColor: '#007bff', color: '#fff', border: 'none', cursor: 'pointer' }}>Search</button>
      </div>
      {error && <p style={{ color: 'red', textAlign: 'center' }}>{error}</p>}
      {record && (
        <div style={{ backgroundColor: '#f9f9f9', padding: '20px', borderRadius: '5px' }}>
          <h3>Record Found:</h3>
          <p>Water Intake: {record.water}</p>
          <p>Sleep: {record.sleepingHour}</p>
          <p>WorkOut in minutes: {record.workout}</p>
          <p>Diet Plan: {record.diet}</p>
          {/* Display other relevant record details */}
        </div>
      )}
    </div>
  );
};

export default WaterRecordComponent;
