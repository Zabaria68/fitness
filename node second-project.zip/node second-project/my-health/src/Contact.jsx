import React, { useEffect, useRef } from 'react';
import Typed from 'typed.js';
import './App.css'; // Import CSS file for styling
import { Link } from 'react-router-dom';
function Contact() {
  const typedTextRef = useRef(null);

  useEffect(() => {
    const options = {
      strings: ['Hello Sir! I HOPE YOU ARE DOING VERY WELL; HEALTH IS A GREAT WEALTH. This is my Contact number +933411019294'],
      typeSpeed: 30, // Typing speed in milliseconds
      loop: true // Whether to loop the typing animation
    };

    const typed = new Typed(typedTextRef.current, options);

    return () => {
      typed.destroy(); // Clean up Typed.js instance on component unmount
    };
  }, []);

  return (
    <div className="contact-container">
      <span ref={typedTextRef}></span>
      <Link to="/wel">
<center>
<button class="mt-6 py-2 px-4 bg-yellow-400 text-gray-800 font-bold rounded-lg shadow-md hover:shadow-lg transition duration-300 ">Back In</button>
</center>
</Link>
    </div>
  );
}

export default Contact;
