import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import { Link } from 'react-router-dom';
import CrudProfile from './CrudProfile';

const Profile = () => {
  const [user, setUser] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const token = localStorage.getItem('token');

      const fetchLoggedInUser = async () => {
        try {
          const response = await axios.get('http://localhost:8000/auth/profile', {
            headers: {
              Authorization: `Bearer ${token}`
            }
          });
          setUser(response.data.user);
        } catch (error) {
          console.error('Error fetching logged-in user:', error.response.data.message);
        }
      };

      if (token) {
        fetchLoggedInUser();
      }
    }
  }, []);

  const handleLogout = () => {
    localStorage.removeItem('token');
    navigate('/');
  };

  return (
    <div className="container-fluid">
      <h2>User Profile</h2>
      {user ? (
        <div className="row">
          <div className="col-md-6">
            <div className="card">
              <div className="card-body">
                <h5 className="card-title">Name: {user.name}</h5>
                <p className="card-text">Email: {user.email}</p>
                {user.image && (
                  <img
                    src={`http://localhost:8000/uploads/${user.image}`}
                    alt={`User ${user.name} Avatar`}
                    className="img-fluid"
                  />
                )}
                <p className="card-text">Role: {user.role}</p>
              </div>
            </div>
          </div>
          <button>
          <div className="col-md-6">
            <CrudProfile />
            <Link to="/" className="btn btn-danger" onClick={handleLogout}>Logout</Link>
          </div>
          </button>
          <Link to="/wel">
<center>
<button class="mt-6 py-2 px-4 bg-yellow-400 text-gray-800 font-bold rounded-lg shadow-md hover:shadow-lg transition duration-300 ">Back In</button>
</center>
</Link>
        </div>
      ) : (
        <p>Loading...</p>
      )}
    </div>
  );
};

export default Profile;
