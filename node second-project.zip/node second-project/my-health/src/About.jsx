import React from 'react';
import './App.css'; // Import CSS file for styling
import {Link} from 'react-router-dom';
const About = () => {
  return (
    <div className="about-container">
      <div className="header">
        <h1>About Our Health App</h1>
      </div>
      <div className="content">
        <p>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam eget velit vel ligula ultrices placerat.
          Phasellus blandit vehicula lectus, eu laoreet lorem aliquet sed. Integer posuere diam ut neque aliquam,
          sit amet venenatis urna facilisis. In hac habitasse platea dictumst. Morbi elementum, nisi sed commodo
          condimentum, magna justo aliquet nisl, id egestas orci magna ut magna. Vivamus consequat suscipit
          bibendum. Aliquam erat volutpat. Donec eleifend nulla eget leo feugiat, id fermentum leo fermentum.
        </p>
        <p>
          Nunc condimentum dolor a posuere. Integer vel sagittis felis. Sed fringilla sapien vitae vestibulum
          rutrum. Vivamus vel ex vitae velit luctus luctus vel id nulla. Nullam eu dolor nec turpis consequat porta.
          Integer eleifend leo eu libero varius, vitae placerat eros tempor. In vitae diam a metus lobortis
          hendrerit. Suspendisse potenti. Sed nec tincidunt nulla, ac accumsan eros. Quisque efficitur, metus non
          tempor efficitur, risus nisi auctor sapien, ac fringilla orci ex vel urna.
        </p>
      </div>

      <Link to="/f">
<center>
<button class="mt-6 py-2 px-4 bg-yellow-400 text-gray-800 font-bold rounded-lg shadow-md hover:shadow-lg transition duration-300 ">Diet Point</button>
</center>
</Link>
      <div className="footer">
        <p>&copy; 2024 Your Health App</p>
      </div>
    </div>
  );
};

export default About;
