import React, { useState } from 'react';
import './App.css'; // Import CSS file for styling

function FigureCalculator() {
  const [weight, setWeight] = useState('');
  const [height, setHeight] = useState('');
  const [bmiResult, setBmiResult] = useState(null);

  const calculateBMI = () => {
    const heightMeters = height / 100; // Convert height to meters
    const bmi = weight / (heightMeters * heightMeters); // BMI calculation formula

    // Determine BMI category
    let category = '';
    if (bmi < 18.5) {
      category = 'Underweight';
    } else if (bmi >= 18.5 && bmi < 25) {
      category = 'Normal weight';
    } else if (bmi >= 25 && bmi < 30) {
      category = 'Overweight';
    } else {
      category = 'Obese';
    }

    setBmiResult({
      bmi: bmi.toFixed(2), // Round BMI to two decimal places
      category: category
    });
  };

  return (
    <div className="figure-calculator-container">
      <h2>Figure Calculator</h2>
      <div className="input-container">
        <label htmlFor="weight">Weight (kg):</label>
        <input
          type="number"
          id="weight"
          value={weight}
          onChange={(e) => setWeight(e.target.value)}
        />
      </div>
      <div className="input-container">
        <label htmlFor="height">Height (cm):</label>
        <input
          type="number"
          id="height"
          value={height}
          onChange={(e) => setHeight(e.target.value)}
        />
      </div>
      <button className="calculate-button" onClick={calculateBMI}>Calculate BMI</button>
      {bmiResult && (
        <div className="result-container">
          <p>BMI: {bmiResult.bmi}</p>
          <p>Category: {bmiResult.category}</p>
        </div>
      )}
    </div>
  );
}

export default FigureCalculator;
