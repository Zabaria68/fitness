let mongoose = require("mongoose")
const connew = mongoose.connect("mongodb://127.0.0.1:27017/exercise")
.then(()=>{console.log("connected to mongodb")})
.catch((err)=>{console.log(err)})

module.exports = connew