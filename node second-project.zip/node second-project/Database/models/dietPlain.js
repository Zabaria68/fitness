const mongoose = require("mongoose");

const DietScheme = new mongoose.Schema({
    diet:{type:String,required:true},
    workout:{type:String,required:true},
    water:{type:Number,required:true},
    sleepingHour:{type:String,required:true}
},
    { timestamps: true }
);

module.exports = mongoose.model("diet", DietScheme);
