const mongoose = require("mongoose");

const Crud = new mongoose.Schema({
    title: { type: String,required:true },
     gender: { type: String ,required:true},
     countryCode: { type: String ,required:true},
     weight: { type: Number,required:true },
    diet: { type: String ,required:true},
     heartbeat: { type: String,required:true },
    height: { type: Number ,required:true},
     age: { type: Number,required:true },
     image: { type: String,required:true }
},
    { timestamps: true }
);

module.exports = mongoose.model("crud", Crud);
