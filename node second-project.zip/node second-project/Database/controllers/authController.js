const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const Auth = require("../models/auth");
const multer = require("multer");
const fs = require('fs').promises;
const path = require('path')

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
      cb(null, path.join(__dirname, "../uploads"));
    },
    filename: (req, file, cb) => {
      const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
      const extension = path.extname(file.originalname);
      const filename = file.fieldname + "-" + uniqueSuffix + extension;
      cb(null, filename);
    },
  });
  const upload = multer({ storage });

const registerUser = async (req, res) => {

    upload.single("image")(req, res, async (err) => {
        if (err) {
            console.error("Error uploading image:", err);
            return res.status(500).json({ error: "Error uploading image." });
        }

        const { name, email, password,role,ban} = req.body;
        const image = req.file ? req.file.filename : null;
        const currentDate = new Date();

  try {

    // Check if the email already exists
    const existingUser = await Auth.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ message: "Email already exists" });
    }

    // Hash the password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Create a new user
    const newUser = new Auth({
      name, email, password: hashedPassword,
      image, role, ban, token: "", createdAt: currentDate,

    });

    // Generate token for the user
    const token = jwt.sign({ _id: newUser._id.toString() }, "123@qwer*asdf");
    newUser.token = token;

    // Save the user to the database
    await newUser.save();

    res.status(201).json({ user: newUser, token });
  } catch (error) {
    res.status(500).json({ message: "Registration failed", error: error.message });
  }
});

};

const getUser = async (req,res) =>{
  try{
    const userData = await Auth.find();
    res.status(200).json(userData) 
}
catch{
    res.status(400).json({ error: error.message });
}
}

const loginUser = async (req, res) => {
    try {
      const { email, password } = req.body;
  
      // Find user by email
      const user = await Auth.findOne({ email });
  
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      if (user.ban==false) {
        return res.status(403).json({ message: "User account is banned. Unable to login." });
      }
      // Compare passwords
      const isPasswordMatch = await bcrypt.compare(password, user.password);
  
      if (!isPasswordMatch) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
  
      // Generate token for the user
      const token = jwt.sign({ _id: user._id.toString() }, "123@qwer*asdf");
  
      res.status(200).json({ user, token });
    } catch (error) {
      res.status(500).json({ message: "Login failed", error: error.message });
    }
  }; 


  const profile = async (req, res) => {
    const UserId = req.params.id; 
  
    try {
        const user = await Auth.findById(UserId);
  
        if (!user) {
            return res.status(404).json({ message: 'User are not available in this area please add correct information' });
        }
  
      
        const { _id, name, email, role, image, ban, token} = user;
  
        res.status(200).json({
            _id, name,
            email,
            role, image, ban,token
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'System error ' });
    }
  };

  const getLoggedInUser = async (req, res) => {
    try {
      const token = req.header("Authorization").replace("Bearer ", "");
      // Verify the token
      const decoded = jwt.verify(token, "123@qwer*asdf");
  
      // Find the user by ID
      const user = await Auth.findById(decoded._id);
  
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
  
      res.status(200).json({ user });

    } catch (error) {
      if (error.name === 'TokenExpiredError') {
        return res.status(401).json({ message: 'Token expired' });
      }
  
      if (error.name === 'JsonWebTokenError') {
        return res.status(401).json({ message: 'Invalid token' });
      }
  
      res.status(500).json({ message: "Error fetching user", error: error.message });
    }
  };
  
  const getSingleUser = async (req, res) => {
    const { id } = req.params;
    const user = await Auth.findById({ _id: id });
    if (!user) {
        return res.status(400).json({ error: "no Record Found!!!" });
    }
    res.status(200).json( user );
};

const logoutUser = async (req, res) => {
  try {
    // Clear the token from the user's document in the database
    const user = await Auth.findById(req.user._id);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    user.token = "";
    await user.save();
    res.status(200).json({ message: "Logout successful" });
  } catch (error) {
    console.error("Logout failed:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};



const uStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, path.join(__dirname, '../uploads'));
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
    const extension = path.extname(file.originalname);
    const filename = file.fieldname + '-' + uniqueSuffix + extension;
    cb(null, filename);
  },
});

const Rupload = multer({ storage: uStorage });

const updateProfile = async (req, res) => {
  const { id } = req.params;

  try {
    // Find the existing test to get the old image filename
    const existingTest = await Auth.findById(id);

    if (!existingTest) {
      console.log('Test not found.');
      return res.status(404).json({ error: 'Test not found.' });
    }

    // Wrap the Rupload.single in a Promise
    const uploadImage = () => {
      return new Promise((resolve, reject) => {
        Rupload.single('image')(req, res, (err) => {
          if (err) {
            console.error('Error uploading image:', err);
            reject(err);
          } else {
            resolve();
          }
        });
      });
    };

    // Await the image upload
    await uploadImage();

    const { name, role, email } = req.body;
    const image = req.file ? req.file.filename : existingTest.image;

    // Update the test with the new data
    const updatedTest = await Auth.findByIdAndUpdate(
      id,
      { name, role, image, email },
      { new: true }
    );

    console.log('Update successful. Updated Test:', updatedTest);

    res.status(200).json(updatedTest);
  } catch (error) {
    console.error('Error updating test:', error);
    res.status(400).json({ error: error.message });
  }
};

const getData = async (req,res)=>{
  try{
      const image = await Auth.find();
      res.status(200).json(image)
  }
  catch{res.status(400).json("nothing found")}
} 

const delUser = async (req, res) => {
  const { id } = req.params;
  const user = await Auth.findByIdAndDelete({ _id: id });
  if (!user) {
      return res.status(400).json({ error: "no Record Found!!!" });
  }

  res.status(200).json({ user });
};

const blockUser = async (req, res) => {
  try {
    const user = await Auth.findById(req.params.id);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    if (user.ban) {
      return res.status(400).json({ message: "User is already banned" });
    }
    user.ban = true;  await user.save();
    return res.status(200).json({ message: "User account is banned", user });
  } catch (err) { console.log(err); return res.status(500).json(err);
  }
};

const resetPassword = async (req, res) => {
  try {
    const { email, newPassword } = req.body;

    // Check if the user with the provided email exists
    const user = await Auth.findOne({ email });

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    // Generate a new hashed password
    const hashedPassword = await bcrypt.hash(newPassword, 10);

    // Log relevant information for debugging
    console.log("User before password update:", user);
    console.log("New hashed password:", hashedPassword);

    // Update the user's password in the database
    try {
      user.password = hashedPassword;
      await user.save();
      console.log("User after password update:", user);
      res.status(200).json({ message: "Password reset successfully" });
    } catch (saveError) {
      console.error("Save error:", saveError);
      res.status(500).json({ message: "Error saving new password" });
    }
  } catch (error) {
    console.error("Error:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};

module.exports = {
  getLoggedInUser, 
  updateProfile, 
  getSingleUser,
  resetPassword,
  registerUser, 
  loginUser, 
  blockUser, 
  getUser, 
  delUser, profile, getData,logoutUser,
}