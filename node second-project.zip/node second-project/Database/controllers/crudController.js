// const CrudModel = require('../models/crud');

// // Create a new record
// const createRecord = async (req, res) => {
//   try {
//     const { title, gender, countryCode, weight, diet, heartbeat, height, age } = req.body;

//     // Create a new instance of CrudModel
//     const newRecord = new CrudModel({
//       title,
//       // gender,
//       // countryCode,
//       // weight,
//       // diet,
//       // heartbeat,
//       // height,
//       // age
//     });

//     // Save the new record
//     const savedRecord = await newRecord.save();

//     res.status(201).json(savedRecord);
//   } catch (error) {
//     console.error(error);
//     res.status(500).json({ error: 'Internal Server Error' });
//   }
// };

// // Read all records
// const readAllRecords = async (req, res) => {
//   try {
//     const records = await CrudModel.find();
//     res.status(200).json(records);
//   } catch (error) {
//     console.error(error);
//     res.status(500).json({ error: 'Internal Server Error' });
//   }
// };

// // Read a single record by ID
// const readRecordById = async (req, res) => {
//   const recordId = req.params.id;

//   try {
//     const record = await CrudModel.findById(recordId);
//     if (!record) {
//       return res.status(404).json({ error: 'Record not found' });
//     }
//     res.status(200).json(record);
//   } catch (error) {
//     console.error(error);
//     res.status(500).json({ error: 'Internal Server Error' });
//   }
// };

// // Update a record by ID
// const updateRecordById = async (req, res) => {
//   const recordId = req.params.id;

//   try {
//     const updatedRecord = await CrudModel.findByIdAndUpdate(recordId, req.body, { new: true });
//     if (!updatedRecord) {
//       return res.status(404).json({ error: 'Record not found' });
//     }
//     res.status(200).json(updatedRecord);
//   } catch (error) {
//     console.error(error);
//     res.status(500).json({ error: 'Internal Server Error' });
//   }
// };

// // Delete a record by ID
// const deleteRecordById = async (req, res) => {
//   const recordId = req.params.id;

//   try {
//     const deletedRecord = await CrudModel.findByIdAndRemove(recordId);
//     if (!deletedRecord) {
//       return res.status(404).json({ error: 'Record not found' });
//     }
//     res.status(204).json();
//   } catch (error) {
//     console.error(error);
//     res.status(500).json({ error: 'Internal Server Error' });
//   }
// };

// module.exports = {
//   createRecord,
//   readAllRecords,
//   readRecordById,
//   updateRecordById,
//   deleteRecordById,
// };


const Blog = require('../models/crud')
const multer = require("multer");
const path = require("path");

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, path.join(__dirname, "../uploads"));
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
    const extension = path.extname(file.originalname);
    const filename = file.fieldname + "-" + uniqueSuffix + extension;
    cb(null, filename);
  },
});

const upload = multer({ storage });

const createRecord = async (req, res) => {
  upload.single("image")(req, res, async (err) => {
    if (err) {
      console.error("Error uploading image:", err);
      return res.status(500).json({ error: "Error uploading image." });
    }

    const { title, gender,countryCode,weight,diet,heartbeat,height,age } = req.body;
    const image = req.file ? req.file.filename : null;
    const currentDate = new Date();

    try {
      const blog = new Blog({
       title, gender,countryCode,weight,diet,heartbeat,height,age,
        image,
        createdAt: currentDate,
      });

      await blog.save();

      res.status(201).json(blog);
    } catch (error) {
      console.error("Error creating blog:", error);
      res.status(400).json({ error: error.message });
    }
  });
};
  
const readAllRecords = async (req,res)=>{
    try{
        const blogData = await Blog.find();
        res.status(200).json(blogData) 
    }
    catch{
        res.status(400).json({ error: error.message });
    }
}


// get single record
const readRecordById = async (req, res) => {
    const { id } = req.params;
    const course = await Blog.findById({ _id: id });
    if (!course) {
        return res.status(400).json({ error: "no Record Found!!!" });
    }

    res.status(200).json( course );
};
// person by one 
// get single record

// Route to fetch records based on height, weight, and countryCode
const findRecordByAttributes = async (req, res) => {
  try {
    const { height, weightRange, countryCode } = req.query;

    // Query the database based on provided attributes
    const records = await Record.find({ 
      height: height,
      weightRange: weightRange,
      countryCode: countryCode
    });

    res.json(records);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server Error' });
  }
};



// delete single record

const  deleteRecordById = async (req, res) => {
    const { id } = req.params;
    const course = await Blog.findByIdAndDelete({ _id: id });
    if (!course) {
        return res.status(400).json({ error: "no Record Found!!!" });
    }

    res.status(200).json({ course });
};


// update reg course
const updateRecordById = async (req, res) => {
    const { id } = req.params;

    const course = await Blog.findByIdAndUpdate({ _id: id }, req.body, {
        new: true,
    });

    if (!course) {
        return res.status(400).json({ error: "No record found!!!" });
    }

    res.status(200).json( course );
};


module.exports = { 
    createRecord,
    readAllRecords,
    findRecordByAttributes,
    readRecordById,
    deleteRecordById,
    updateRecordById,
}

