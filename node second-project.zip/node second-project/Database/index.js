const express = require('express');
const app = express();
const cors = require('cors');
const path = require('path');
const port = 8000;

const authRoute = require('./routes/authRoute');
const crudRoute = require('./routes/crudRoute');
const dietRoute = require('./routes/dietRoute');
// const prodRoute = require('./routes/prodRoute');
// const cartRoute = require("./routes/cartRoute")
require('./connect');

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true })); // Comment this line out

  
app.use('/auth', authRoute);
app.use('/crud', crudRoute);
app.use('/diet', dietRoute);
// app.use("/prods",prodRoute);
// app.use("/cart",cartRoute);

app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
app.use('/products', express.static(path.join(__dirname, 'products')));
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).send('Something went wrong!');
  });
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});