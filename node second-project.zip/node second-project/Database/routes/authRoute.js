const express = require("express");
const router = express.Router();

const {
    registerUser, 
    loginUser,
    getLoggedInUser,
    updateProfile,
    getUser,delUser, 
    blockUser, 
    getSingleUser,
    resetPassword,
    profile, getData,logoutUser

} = require("../controllers/authController");

router.post("/user", registerUser);
router.post("/log", loginUser);
router.get("/block/:id",blockUser)
router.get("/profile", getLoggedInUser);
router.put("/update/:id", updateProfile);
router.get("/single/:id", getSingleUser);
router.get("/allUsers", getUser);
router.delete("/del/:id", delUser); 
router.post("/reset", resetPassword);
router.get("/profile/:id", profile) 
router.get("/fetch", getData);
router.post('/logout', logoutUser);



module.exports = router;