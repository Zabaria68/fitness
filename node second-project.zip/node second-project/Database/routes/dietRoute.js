
const express = require('express');
const router = express.Router();
// eslint disable this line
const dietController = require('../controllers/dietController');


router.post('/fill', dietController.createRecord);
router.get('/fillall', dietController.readAllRecords);
router.get('/height/:water', dietController.readRecordByheight);

router.get('/fillfind/search', dietController.findRecordByAttributes);
router.get('/record/:id', dietController.readRecordById);
router.put('/fillupdate/:id', dietController.updateRecordById);

router.delete('/record/:id', dietController.deleteRecordById);

module.exports = router;
