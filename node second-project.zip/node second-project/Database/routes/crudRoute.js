const express = require('express');
const router = express.Router();

const {
  createRecord,
  readAllRecords,
  findRecordByAttributes,
   readRecordById,
   updateRecordById,
 deleteRecordById,
} = require('../controllers/crudController'); 

router.post('/record', createRecord);
router.get('/allRecords', readAllRecords);
router.get('/one/:height/:countryCode/:weight', findRecordByAttributes);
 router.get('/record/:id', readRecordById);
 router.put('/updateRecord/:id', updateRecordById);
 router.delete('/deleteRecord/:id', deleteRecordById);

module.exports = router;
